from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from flask_login import current_user
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField, IntegerField, DateField, SelectField, HiddenField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError, Regexp
from wtforms.ext.sqlalchemy.fields import QuerySelectField
from flaskDemo import db
from flaskDemo.models import User, Team, Player, Coach, Trainer, Referee, Game, Arena
from wtforms.fields.html5 import DateField

'''Queries for the drop-down choices when creating a new game'''

game = Game.query.with_entities(Game.gameID).distinct()
#  or could have used ssns = db.session.query(Department.mgr_ssn).distinct()
# for that way, we would have imported db from flaskDemo, see above
myChoices2 = [(row[0],row[0]) for row in game]  # change
results=list()
for row in game:
    rowDict=row._asdict()
    results.append(rowDict)
myChoices = [(row['gameID'],row['gameID']) for row in results]

#drop down list for teams (we will have two of these)
team = Team.query.with_entities(Team.teamID, Team.schoolname).distinct()
results=list()
for row in team:
    rowDict=row._asdict()
    results.append(rowDict)
TeamChoices = [(row['teamID'],row['schoolname']) for row in results]

#drop down list for the arena
arena = Arena.query.with_entities(Arena.name).distinct()
results=list()
for row in arena:
    rowDict=row._asdict()
    results.append(rowDict)
ArenaChoices = [(row['name'],row['name']) for row in results]

#drop down list for the referees
ref = Referee.query.with_entities(Referee.refID, Referee.lname).distinct()
results=list()
for row in ref:
    rowDict=row._asdict()
    results.append(rowDict)
RefereeChoices = [(row['refID'],row['lname']) for row in results]

class RegistrationForm(FlaskForm):
    username = StringField('Username',
                           validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('That username is taken. Please choose a different one.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('That email is taken. Please choose a different one.')


class LoginForm(FlaskForm):
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class UpdateAccountForm(FlaskForm):
    username = StringField('Username',
                           validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    picture = FileField('Update Profile Picture', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Update')

    def validate_username(self, username):
        if username.data != current_user.username:
            user = User.query.filter_by(username=username.data).first()
            if user:
                raise ValidationError('That username is taken. Please choose a different one.')

    def validate_email(self, email):
        if email.data != current_user.email:
            user = User.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('That email is taken. Please choose a different one.')

class PostForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    content = TextAreaField('Content', validators=[DataRequired()])
    submit = SubmitField('Post')

'''Adding & Updating a Game'''

class GameUpdateForm(FlaskForm):
    date = DateField("Date", format='%Y-%m-%d')
    team1 = HiddenField("")
    team2 = HiddenField("")
    ref = HiddenField("")
    winner = StringField('Winner')
    arena = SelectField("Arena", choices=ArenaChoices)
    tickets = HiddenField("")
    submit = SubmitField('Update this Game')

    def validate_winner(self, winner):
        w = Team.query.filter_by(schoolname = winner.data).first()
        t1 = Team.query.filter_by(teamID = self.team1.data).first()
        t2 = Team.query.filter_by(teamID = self.team2.data).first()
        if str(t1.schoolname) != str(t2.schoolname):
            if (str(w.schoolname) != str(t1.schoolname) and str(w.schoolname) != str(t2.schoolname)):
               raise ValidationError('The Winner must be Team 1 or Team 2. Check your spelling!')
        else: 
           raise ValidationError('Team 1 and Team 2 cannot be the same team. Please choose 2 different teams!')
            
        
class GameForm(GameUpdateForm):
    date = DateField("Date", format='%Y-%m-%d')
    team1 = SelectField("Team1", choices=TeamChoices)
    team2 = SelectField("Team2", choices=TeamChoices)
    ref = SelectField("Referee", choices = RefereeChoices)
    winner = StringField('Predicted Winner')
    arena = SelectField("Arena", choices=ArenaChoices)
    tickets = StringField('Tickets')
    submit = SubmitField('Create Game')
    



