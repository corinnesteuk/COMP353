#!/bin/bash

source ./env.sh

flask run