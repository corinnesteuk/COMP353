from flask import Flask, render_template, url_for
app = Flask(__name__)


favSnacks = [["Nestle's Crunch", 250],["Lay's All-Natural Potato Chips with Sea Salt", 200], ["Something Healthy", 150]]
favSnack = [{}]


@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html', title='Home')


@app.route("/about")
def about():
    return render_template('about.html', title='About')

    
@app.route("/lab")
def lab():
    return render_template('lab.html', title = " Corinne's Lab", favSnack = favSnacks)


