# When you add something to the list, the list contains a reference to that object, not a copy!!
# So, if you change the value of the Snack dictionary entry (which we are doing), and append it again,
# you will end up with two references to the the updated dictionary entry.
# The solution is to create a new dictionary for each entry to be added to the list.
Snacks = list()
Snack = dict()
Snack['snack']="Nestle's Crunch"
Snack['calories'] = 101
Snacks.append(Snack)
Snack=dict()
print(Snacks)
Snack['snack']="KitKat"
Snack['calories'] = 202
Snacks.append(Snack)
print(Snacks)
