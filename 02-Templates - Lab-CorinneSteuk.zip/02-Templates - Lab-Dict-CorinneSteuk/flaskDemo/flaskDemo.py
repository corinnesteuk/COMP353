from flask import Flask, render_template, url_for
app = Flask(__name__)

FavSnacks = list()
FavSnack = dict()
FavSnack['snack']="Nestle's Crunch"
FavSnack['calories'] = 101
FavSnacks.append(FavSnack)
FavSnack=dict()

FavSnack['snack']="KitKat"
FavSnack['calories'] = 202
FavSnacks.append(FavSnack)
FavSnack=dict()
FavSnack['snack']="Yogurt"
FavSnack['calories'] = 100
FavSnacks.append(FavSnack)
FavSnack=dict()
FavSnack['snack']="Fruit"
FavSnack['calories'] = 50
FavSnacks.append(FavSnack)

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html', title='Home')


@app.route("/about")
def about():
    return render_template('about.html', title='About')

    
@app.route("/lab")
def lab():
    return render_template('lab.html', title = "Corinne's Lab", FavSnack = FavSnacks)


