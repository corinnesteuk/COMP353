from flask import Flask, render_template, url_for
app = Flask(__name__)


favSnacks = ['mango slices', 'smoothie', 'orange', 'granola bar']
posts = [{}]


@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html', title='Home')


@app.route("/about")
def about():
    return render_template('about.html', title='About')

    
@app.route("/lab")
def lab():
    return render_template('lab.html', title = "Corinne's Lab", posts = favSnacks)


