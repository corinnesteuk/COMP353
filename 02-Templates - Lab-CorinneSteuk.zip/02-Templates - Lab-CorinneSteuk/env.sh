#!/bin/bash

export FLASK_APP=flaskDemo/flaskDemo.py
export FLASK_DEBUG=1
